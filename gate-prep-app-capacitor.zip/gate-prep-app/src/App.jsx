import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  Home, Zap, BookOpen, FileText, Menu, Sun, Moon, ChevronLeft,
  ChevronRight, Check, X, Flame, Target, TrendingUp, ExternalLink,
  GraduationCap, ListChecks, Youtube, RotateCcw, ArrowRight, Award,
  Search, Sparkles, StickyNote, ClipboardList,
  Calculator, ChevronDown, ChevronUp, Compass, RefreshCw, AlertCircle
} from "lucide-react";

/* ============================================================
   FONTS
   ============================================================ */
function useFonts() {
  useEffect(() => {
    const id = "gate-prep-fonts";
    if (document.getElementById(id)) return;
    const link = document.createElement("link");
    link.id = id;
    link.rel = "stylesheet";
    link.href =
      "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&display=swap";
    document.head.appendChild(link);
  }, []);
}

/* ============================================================
   THEME TOKENS
   ============================================================ */
const THEMES = {
  light: {
    bg: "#F6F4EE",
    surface: "#FFFFFF",
    surfaceAlt: "#EDEAE0",
    ink: "#1B2333",
    inkMuted: "#646C7A",
    accent: "#2451C4",
    accentSoft: "#DEE6FB",
    correct: "#2E7D5B",
    correctSoft: "#DDEEE4",
    wrong: "#C24B3F",
    wrongSoft: "#F8E1DD",
    border: "#E3DFD2",
    shadow: "0 1px 2px rgba(27,35,51,0.06), 0 1px 1px rgba(27,35,51,0.04)",
  },
  dark: {
    bg: "#10131C",
    surface: "#1A1F2C",
    surfaceAlt: "#232A3B",
    ink: "#ECEAE2",
    inkMuted: "#9AA1B2",
    accent: "#6C8FF0",
    accentSoft: "#233158",
    correct: "#57B58C",
    correctSoft: "#1B3B2F",
    wrong: "#E27B6E",
    wrongSoft: "#3D231F",
    border: "#2A3040",
    shadow: "0 1px 2px rgba(0,0,0,0.4)",
  },
};

const FONT_DISPLAY = "'Space Grotesk', sans-serif";
const FONT_BODY = "'Inter', sans-serif";
const FONT_MONO = "'IBM Plex Mono', monospace";

/* ============================================================
   DATA: BRANCHES + SUBJECTS
   ============================================================ */
const BRANCHES = [
  { id: "ECE", name: "Electronics & Communication", short: "ECE" },
  { id: "CSE", name: "Computer Science & IT", short: "CSE" },
  { id: "EE", name: "Electrical Engineering", short: "EE" },
  { id: "ME", name: "Mechanical Engineering", short: "ME" },
  { id: "CE", name: "Civil Engineering", short: "CE" },
  { id: "IT", name: "Information Technology", short: "IT" },
];

const SUBJECTS_BY_BRANCH = {
  ECE: ["Engineering Mathematics", "Network Theory", "Signals and Systems", "Electronic Devices",
    "Analog Electronics", "Digital Electronics", "Control Systems", "Communication Systems",
    "Electromagnetics", "General Aptitude"],
  CSE: ["Engineering Mathematics", "Digital Logic", "Computer Organization & Architecture",
    "Programming & Data Structures", "Algorithms", "Theory of Computation", "Compiler Design",
    "Operating Systems", "Databases", "Computer Networks", "General Aptitude"],
  EE: ["Engineering Mathematics", "Electric Circuits", "Electromagnetic Fields", "Signals and Systems",
    "Electrical Machines", "Power Systems", "Control Systems", "Electrical & Electronic Measurements",
    "Analog and Digital Electronics", "Power Electronics", "General Aptitude"],
  ME: ["Engineering Mathematics", "Engineering Mechanics", "Strength of Materials", "Theory of Machines",
    "Vibrations", "Machine Design", "Fluid Mechanics", "Heat Transfer", "Thermodynamics",
    "Manufacturing Engineering", "Industrial Engineering", "General Aptitude"],
  CE: ["Engineering Mathematics", "Structural Engineering", "Geotechnical Engineering",
    "Water Resources Engineering", "Environmental Engineering", "Transportation Engineering",
    "Surveying", "Construction Materials and Management", "General Aptitude"],
  IT: ["Engineering Mathematics", "Digital Logic", "Computer Organization & Architecture",
    "Programming & Data Structures", "Algorithms", "Theory of Computation", "Operating Systems",
    "Databases", "Computer Networks", "General Aptitude"],
};

/* ============================================================
   DATA: QUESTION BANKS
   Note: PYQ items are original GATE-style practice questions
   modeled on the syllabus, not verbatim reproductions of any
   official paper. For authentic archived papers, see Resources.
   ============================================================ */
const DAILY_BANK = [
  // ECE
  { id: "ece-d1", branches: ["ECE"], subject: "Engineering Mathematics", q: "The eigenvalues of the matrix [[2,0],[0,3]] are:", options: ["2 and 3", "0 and 1", "2 and 2", "3 and 3"], correct: 0, explanation: "For a diagonal matrix, the eigenvalues are simply the diagonal entries: 2 and 3." },
  { id: "ece-d2", branches: ["ECE"], subject: "Network Theory", q: "In a purely resistive circuit, the phase difference between voltage and current is:", options: ["0°", "90°", "180°", "45°"], correct: 0, explanation: "Voltage and current are in phase across a pure resistor, so the phase difference is 0°." },
  { id: "ece-d3", branches: ["ECE"], subject: "Signals and Systems", q: "The Fourier transform of a unit impulse function δ(t) is:", options: ["1", "0", "u(t)", "δ(f)"], correct: 0, explanation: "δ(t) contains all frequencies with equal magnitude 1, so its Fourier transform is the constant 1." },
  { id: "ece-d4", branches: ["ECE"], subject: "Electronic Devices", q: "In an intrinsic semiconductor, the number of free electrons is __ the number of holes.", options: ["equal to", "greater than", "less than", "unrelated to"], correct: 0, explanation: "In an intrinsic (pure) semiconductor, electron-hole pairs are generated together, so their concentrations are equal." },
  { id: "ece-d5", branches: ["ECE"], subject: "Digital Electronics", q: "How many flip-flops are required to design a MOD-10 counter?", options: ["3", "4", "5", "10"], correct: 1, explanation: "n flip-flops give 2^n states. 2^3 = 8 is not enough, so 4 flip-flops (2^4 = 16 states, truncated to 10) are needed." },
  { id: "ece-d6", branches: ["ECE"], subject: "Control Systems", q: "A system is said to be BIBO stable if its impulse response is:", options: ["Absolutely integrable", "Periodic", "Unbounded", "Always zero"], correct: 0, explanation: "Bounded-Input Bounded-Output stability requires the impulse response h(t) to be absolutely integrable." },
  // CSE / IT
  { id: "cse-d1", branches: ["CSE", "IT"], subject: "Programming & Data Structures", q: "What is the time complexity of binary search on a sorted array of n elements?", options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"], correct: 1, explanation: "Binary search halves the search space each step, giving O(log n) time." },
  { id: "cse-d2", branches: ["CSE", "IT"], subject: "Algorithms", q: "Which sorting algorithm has the best average-case time complexity among these?", options: ["Bubble Sort", "Insertion Sort", "Merge Sort", "Selection Sort"], correct: 2, explanation: "Merge Sort has an average and worst-case time complexity of O(n log n), better than the O(n²) options." },
  { id: "cse-d3", branches: ["CSE", "IT"], subject: "Operating Systems", q: "Which scheduling algorithm can lead to starvation?", options: ["Round Robin", "First Come First Served", "Priority Scheduling", "None of these"], correct: 2, explanation: "In priority scheduling, low-priority processes may never get the CPU if high-priority ones keep arriving." },
  { id: "cse-d4", branches: ["CSE", "IT"], subject: "Databases", q: "Which normal form removes transitive dependency?", options: ["1NF", "2NF", "3NF", "BCNF"], correct: 2, explanation: "Third Normal Form (3NF) requires that non-key attributes depend only on the key, eliminating transitive dependencies." },
  { id: "cse-d5", branches: ["CSE", "IT"], subject: "Computer Networks", q: "Which layer of the OSI model is responsible for routing?", options: ["Data Link", "Network", "Transport", "Session"], correct: 1, explanation: "The Network layer handles logical addressing and routing of packets between networks." },
  { id: "cse-d6", branches: ["CSE", "IT"], subject: "Theory of Computation", q: "Which of the following languages is regular?", options: ["{aⁿbⁿ | n ≥ 0}", "{aⁿbⁿcⁿ | n ≥ 0}", "a* (any string of only a's)", "Set of all palindromes"], correct: 2, explanation: "a* can be described by a finite automaton with a single self-loop, so it is regular. The others require counting, which finite automata cannot do." },
  // EE
  { id: "ee-d1", branches: ["EE"], subject: "Electric Circuits", q: "In a series RLC circuit at resonance, the impedance is:", options: ["Maximum and purely reactive", "Minimum and purely resistive", "Zero", "Infinite"], correct: 1, explanation: "At resonance the inductive and capacitive reactances cancel, leaving only resistance R — the minimum possible impedance." },
  { id: "ee-d2", branches: ["EE"], subject: "Electrical Machines", q: "The speed of a DC shunt motor is inversely proportional to:", options: ["Armature current", "Flux per pole", "Supply voltage", "Load torque"], correct: 1, explanation: "Speed N ∝ Eb / φ, so for a fixed back-emf, speed decreases as flux φ increases." },
  { id: "ee-d3", branches: ["EE"], subject: "Power Systems", q: "The unit of reactive power is:", options: ["Watt", "VAR", "VA", "Joule"], correct: 1, explanation: "Reactive power is measured in Volt-Ampere Reactive (VAR)." },
  { id: "ee-d4", branches: ["EE"], subject: "Control Systems", q: "The number of branches of a root locus equals the number of:", options: ["Zeros of the open-loop transfer function", "Poles of the open-loop transfer function", "Closed-loop poles only", "Break-away points"], correct: 1, explanation: "The root locus has as many branches as there are open-loop poles." },
  { id: "ee-d5", branches: ["EE"], subject: "Electrical & Electronic Measurements", q: "A Wheatstone bridge is typically used to measure:", options: ["Very high resistance", "Very low resistance", "Medium resistance accurately", "Capacitance only"], correct: 2, explanation: "The Wheatstone bridge gives accurate results for medium resistance values (a few ohms to a few mega-ohms)." },
  { id: "ee-d6", branches: ["EE"], subject: "Power Electronics", q: "A thyristor (SCR) is turned off by:", options: ["Applying a gate pulse", "Reducing the anode current below the holding current", "Increasing the anode voltage", "None of these"], correct: 1, explanation: "Once triggered, the gate loses control; the SCR turns off only when anode current falls below the holding current." },
  // ME
  { id: "me-d1", branches: ["ME"], subject: "Thermodynamics", q: "The efficiency of a Carnot engine depends only on:", options: ["The working substance used", "The temperatures of the source and sink", "The pressure of operation", "The volume of the cylinder"], correct: 1, explanation: "Carnot efficiency = 1 − Tsink/Tsource, independent of the working substance." },
  { id: "me-d2", branches: ["ME"], subject: "Strength of Materials", q: "The ratio of lateral strain to longitudinal strain is called:", options: ["Young's modulus", "Poisson's ratio", "Bulk modulus", "Shear modulus"], correct: 1, explanation: "Poisson's ratio quantifies how much a material contracts laterally when stretched longitudinally." },
  { id: "me-d3", branches: ["ME"], subject: "Theory of Machines", q: "The degree of freedom of a rigid body moving in a plane is:", options: ["1", "2", "3", "6"], correct: 2, explanation: "A rigid body in planar motion has 2 translational and 1 rotational degree of freedom, totalling 3." },
  { id: "me-d4", branches: ["ME"], subject: "Fluid Mechanics", q: "The Reynolds number is the ratio of:", options: ["Inertial force to viscous force", "Gravity force to viscous force", "Pressure force to inertial force", "Surface tension to gravity force"], correct: 0, explanation: "Re = inertial force / viscous force, used to predict laminar or turbulent flow." },
  { id: "me-d5", branches: ["ME"], subject: "Heat Transfer", q: "Which mode of heat transfer does not require a medium?", options: ["Conduction", "Convection", "Radiation", "None of these"], correct: 2, explanation: "Radiation can travel through a vacuum, unlike conduction and convection which need a medium." },
  { id: "me-d6", branches: ["ME"], subject: "Manufacturing Engineering", q: "In orthogonal cutting, the cutting edge is oriented __ to the direction of relative tool motion.", options: ["Parallel", "Perpendicular", "At 45°", "At 60°"], correct: 1, explanation: "Orthogonal cutting is defined by the cutting edge being perpendicular to the direction of tool travel." },
  // CE
  { id: "ce-d1", branches: ["CE"], subject: "Structural Engineering", q: "A simply supported beam with a central point load has maximum bending moment at:", options: ["The supports", "Mid-span", "Quarter span", "Nowhere in particular"], correct: 1, explanation: "For a central point load, bending moment increases linearly from zero at the supports to a maximum at mid-span." },
  { id: "ce-d2", branches: ["CE"], subject: "Geotechnical Engineering", q: "The property of soil that allows water to pass through it is called:", options: ["Porosity", "Permeability", "Plasticity", "Compressibility"], correct: 1, explanation: "Permeability describes how easily water can flow through the soil's void spaces." },
  { id: "ce-d3", branches: ["CE"], subject: "Surveying", q: "A theodolite is primarily used to measure:", options: ["Distances only", "Horizontal and vertical angles", "Elevation only", "Area only"], correct: 1, explanation: "A theodolite is an angle-measuring instrument for both horizontal and vertical planes." },
  { id: "ce-d4", branches: ["CE"], subject: "Water Resources Engineering", q: "Flow in an open channel is classified mainly based on:", options: ["Water temperature", "Variation of depth with time and space", "Color of the water", "Channel material"], correct: 1, explanation: "Open channel flow is categorized as steady/unsteady and uniform/non-uniform based on how depth varies with time and distance." },
  { id: "ce-d5", branches: ["CE"], subject: "Environmental Engineering", q: "BOD commonly stands for:", options: ["Biological Oxygen Demand", "Biochemical Oxygen Demand", "Basic Organic Density", "Bio-Organic Discharge"], correct: 1, explanation: "BOD (Biochemical Oxygen Demand) measures the oxygen required by microorganisms to break down organic matter in water." },
  { id: "ce-d6", branches: ["CE"], subject: "Transportation Engineering", q: "Camber is provided on roads mainly to:", options: ["Increase vehicle speed", "Drain off rainwater from the surface", "Reduce construction cost", "Increase surface friction"], correct: 1, explanation: "Camber is the cross-slope given to a road surface so that rainwater drains off quickly." },
];

const PYQ_BANK = [
  { id: "ece-p1", branch: "ECE", subject: "Network Theory", year: 2021, q: "The Thevenin equivalent resistance of a network is found by:", options: ["Deactivating all independent sources and finding resistance across the terminals", "Measuring short-circuit current only", "Measuring open-circuit voltage only", "None of these"], correct: 0, explanation: "Thevenin resistance is obtained by turning off (deactivating) all independent sources and calculating the resistance seen from the open terminals." },
  { id: "ece-p2", branch: "ECE", subject: "Digital Electronics", year: 2022, q: "A JK flip-flop with J = K = 1 acts as a:", options: ["Latch", "Toggle", "Reset", "Set"], correct: 1, explanation: "When J = K = 1, the JK flip-flop toggles its output on every clock pulse." },
  { id: "ece-p3", branch: "ECE", subject: "Signals and Systems", year: 2023, q: "For a causal, stable discrete-time LTI system, the region of convergence (ROC) must:", options: ["Include the origin only", "Include the unit circle", "Exclude the unit circle", "Be the entire z-plane"], correct: 1, explanation: "A causal, stable system has all poles inside the unit circle, so the ROC (outside the outermost pole) must include the unit circle." },
  { id: "ece-p4", branch: "ECE", subject: "Electromagnetics", year: 2024, q: "The unit of electric flux density (D) is:", options: ["C/m²", "V/m", "N/C", "Tesla"], correct: 0, explanation: "Electric flux density D is charge per unit area, measured in Coulombs per square metre (C/m²)." },
  { id: "cse-p1", branch: "CSE", subject: "Programming & Data Structures", year: 2021, q: "Which data structure follows the Last-In-First-Out (LIFO) order?", options: ["Queue", "Stack", "Tree", "Graph"], correct: 1, explanation: "A stack removes the most recently added element first, which is the definition of LIFO." },
  { id: "cse-p2", branch: "CSE", subject: "Operating Systems", year: 2022, q: "A deadlock can be prevented by ensuring that at least one of the following does not hold:", options: ["Coffman conditions", "Amdahl's Law", "The CAP theorem", "None of these"], correct: 0, explanation: "Deadlocks require all four Coffman conditions (mutual exclusion, hold-and-wait, no preemption, circular wait) to hold simultaneously; breaking any one prevents deadlock." },
  { id: "cse-p3", branch: "CSE", subject: "Databases", year: 2023, q: "A candidate key chosen as the main identifier of a table is called the:", options: ["Foreign key", "Primary key", "Super key", "Alternate key"], correct: 1, explanation: "The primary key is the candidate key selected to uniquely identify rows in a table." },
  { id: "cse-p4", branch: "CSE", subject: "Computer Networks", year: 2024, q: "TCP is best described as a __ protocol.", options: ["Connectionless", "Connection-oriented", "Unreliable", "Broadcast-only"], correct: 1, explanation: "TCP establishes a connection (via the three-way handshake) before transferring data reliably." },
  { id: "ee-p1", branch: "EE", subject: "Electric Circuits", year: 2021, q: "The superposition theorem is applicable only to:", options: ["Linear circuits", "Nonlinear circuits", "All circuits", "None of these"], correct: 0, explanation: "Superposition relies on linearity, so it only applies to circuits made of linear elements." },
  { id: "ee-p2", branch: "EE", subject: "Electrical Machines", year: 2022, q: "An induction motor running exactly at synchronous speed produces:", options: ["Maximum torque", "Zero torque", "Negative torque", "Rated torque"], correct: 1, explanation: "At synchronous speed the slip is zero, so there is no relative motion to induce rotor current, giving zero torque." },
  { id: "ee-p3", branch: "EE", subject: "Power Systems", year: 2023, q: "Corona loss on a transmission line increases with:", options: ["Decrease in conductor spacing", "Increase in operating voltage", "Decrease in operating voltage", "None of these"], correct: 1, explanation: "Higher voltage increases the electric field stress at the conductor surface, increasing corona loss." },
  { id: "ee-p4", branch: "EE", subject: "Control Systems", year: 2024, q: "For a stable feedback system, the gain margin (in dB) is generally:", options: ["Negative", "Positive", "Exactly zero", "Undefined"], correct: 1, explanation: "A positive gain margin (in dB) indicates the system can tolerate additional gain before becoming unstable." },
  { id: "me-p1", branch: "ME", subject: "Thermodynamics", year: 2021, q: "The Coefficient of Performance (COP) of a refrigerator is:", options: ["Always less than 1", "Generally greater than 1", "Always exactly 1", "Always negative"], correct: 1, explanation: "Unlike engine efficiency, COP compares heat moved to work input and can exceed 1." },
  { id: "me-p2", branch: "ME", subject: "Strength of Materials", year: 2022, q: "In a beam under pure bending, bending stress is maximum at the:", options: ["Neutral axis", "Extreme fibre", "Centroid", "Support only"], correct: 1, explanation: "Bending stress varies linearly from zero at the neutral axis to a maximum at the extreme fibre." },
  { id: "me-p3", branch: "ME", subject: "Fluid Mechanics", year: 2023, q: "Bernoulli's equation is derived from the conservation of:", options: ["Mass", "Momentum", "Energy", "Electric charge"], correct: 2, explanation: "Bernoulli's equation expresses conservation of mechanical energy along a streamline." },
  { id: "me-p4", branch: "ME", subject: "Manufacturing Engineering", year: 2024, q: "Which welding process uses a non-consumable tungsten electrode?", options: ["MIG welding", "TIG welding", "Arc welding", "Resistance welding"], correct: 1, explanation: "TIG (Tungsten Inert Gas) welding uses a non-consumable tungsten electrode with a separate filler rod." },
  { id: "ce-p1", branch: "CE", subject: "Structural Engineering", year: 2021, q: "A point of contraflexure is a point where the bending moment is:", options: ["Maximum", "Minimum", "Zero", "Infinite"], correct: 2, explanation: "At a point of contraflexure, the beam changes curvature and the bending moment passes through zero." },
  { id: "ce-p2", branch: "CE", subject: "Geotechnical Engineering", year: 2022, q: "Consolidation settlement of saturated clay is primarily due to:", options: ["Expulsion of pore water over time", "Addition of water", "Chemical reaction in soil", "Temperature rise"], correct: 0, explanation: "Consolidation is the gradual reduction in volume as excess pore water pressure dissipates and water is expelled." },
  { id: "ce-p3", branch: "CE", subject: "Surveying", year: 2023, q: "A contour line on a map joins points of equal:", options: ["Elevation", "Distance from a datum point", "Slope", "Area"], correct: 0, explanation: "Contour lines connect points on the ground that share the same elevation above a reference datum." },
  { id: "ce-p4", branch: "CE", subject: "Environmental Engineering", year: 2024, q: "The most widely used method for disinfecting water supplies is:", options: ["Boiling", "Chlorination", "Filtration", "Sedimentation"], correct: 1, explanation: "Chlorination is the most common, cost-effective method of disinfecting large-scale water supplies." },
];

const APTITUDE_BANK = [
  { id: "apt-q1", category: "Quantitative Aptitude", q: "If the ratio of two numbers is 3:4 and their sum is 63, the smaller number is:", options: ["24", "27", "28", "36"], correct: 1, explanation: "Smaller number = (3/7) × 63 = 27." },
  { id: "apt-q2", category: "Quantitative Aptitude", q: "A train 120 m long crosses a pole in 12 seconds. Its speed is:", options: ["10 km/h", "12 km/h", "36 km/h", "100 km/h"], correct: 2, explanation: "Speed = 120 m / 12 s = 10 m/s = 10 × 18/5 = 36 km/h." },
  { id: "apt-q3", category: "Quantitative Aptitude", q: "The simple interest on Rs. 1000 at 10% per annum for 2 years is:", options: ["Rs. 100", "Rs. 150", "Rs. 200", "Rs. 210"], correct: 2, explanation: "SI = (P × R × T)/100 = (1000 × 10 × 2)/100 = Rs. 200." },
  { id: "apt-r1", category: "Logical Reasoning", q: "Find the odd one out: Apple, Mango, Potato, Banana", options: ["Apple", "Mango", "Potato", "Banana"], correct: 2, explanation: "Potato is a vegetable; the rest are fruits." },
  { id: "apt-r2", category: "Logical Reasoning", q: "If A=1, B=2 ... Z=26, and letters are coded by concatenating their positions, DOG is coded as:", options: ["4157", "41157", "4517", "41577"], correct: 1, explanation: "D=4, O=15, G=7, so concatenating gives 4-15-7 → 41157." },
  { id: "apt-r3", category: "Logical Reasoning", q: "Complete the series: 2, 6, 12, 20, 30, ?", options: ["36", "40", "42", "44"], correct: 2, explanation: "Differences are 4, 6, 8, 10, 12 (each term is n(n+1)); the next term is 6×7 = 42." },
  { id: "apt-e1", category: "English", q: "Choose the correct synonym for 'Abundant':", options: ["Scarce", "Plentiful", "Empty", "Rare"], correct: 1, explanation: "'Abundant' means existing in large quantities — closest in meaning to 'Plentiful'." },
  { id: "apt-e2", category: "English", q: "Choose the correctly spelled word:", options: ["Accomodate", "Acommodate", "Accommodate", "Acomodate"], correct: 2, explanation: "The correct spelling is 'Accommodate' — with double 'c' and double 'm'." },
  { id: "apt-e3", category: "English", q: "Fill in the blank: She is good ___ mathematics.", options: ["at", "in", "on", "with"], correct: 0, explanation: "The correct idiomatic preposition is 'good at' a subject." },
];

const APTITUDE_CATEGORIES = ["Quantitative Aptitude", "Logical Reasoning", "English"];

/* ============================================================
   LEARNING RESOURCES HUB
   Every external link below points to a real, publicly
   accessible official site or channel homepage (verified).
   Nothing here is hosted or copied — only organized links.
   "internal" resources jump to a screen already inside this app.
   ============================================================ */
const RES_TYPES = ["Video", "Notes", "PYQ", "Mock Test", "Formula Sheet", "Official"];
const RES_DIFFICULTY = ["Beginner", "Intermediate", "Advanced"];

const RESOURCE_HUB = [
  // ---------------- Official Resources ----------------
  { id: "off1", section: "Official Resources", name: "NPTEL GATE Portal", desc: "Official portal built specifically to help students prepare for GATE with structured video courses.", url: "https://gate.nptel.ac.in", type: "Official", difficulty: "Beginner" },
  { id: "off2", section: "Official Resources", name: "SWAYAM", desc: "Government MOOC platform hosting free, certified courses across every engineering discipline.", url: "https://swayam.gov.in", type: "Official", difficulty: "Beginner" },
  { id: "off3", section: "Official Resources", name: "NPTEL", desc: "Free video lectures from IIT/IISc faculty — the deepest, most rigorous free content available.", url: "https://nptel.ac.in", type: "Official", difficulty: "Intermediate" },
  { id: "off4", section: "Official Resources", name: "e-PG Pathshala", desc: "UGC-backed e-content repository with postgraduate-level modules useful for advanced topics.", url: "https://epgp.inflibnet.ac.in", type: "Official", difficulty: "Advanced" },
  { id: "off5", section: "Official Resources", name: "SATHEE", desc: "Ministry of Education's free AI-assisted learning and doubt-solving platform.", url: "https://sathee.prutor.ai", type: "Official", difficulty: "Beginner" },
  { id: "off6", section: "Official Resources", name: "Official GATE website & syllabus", desc: "The organizing IIT changes every year — search brings you to the current cycle's official site.", url: "https://www.google.com/search?q=official+GATE+exam+website+syllabus", type: "Official", difficulty: "Beginner" },

  // ---------------- Free Video Lectures ----------------
  { id: "vid1", section: "Free Video Lectures", name: "Gate Smashers", desc: "Hindi/English lectures for CSE core subjects — DSA, OS, DBMS, CN, TOC and more.", url: "https://www.youtube.com/@gatesmashers", type: "Video", difficulty: "Beginner", branches: ["CSE", "IT"] },
  { id: "vid2", section: "Free Video Lectures", name: "GATE ACADEMY by Umesh Dhande", desc: "Conceptual lectures spanning nearly every GATE branch, built up over 15+ years.", url: "https://www.youtube.com/@gate_academy", type: "Video", difficulty: "Intermediate" },
  { id: "vid3", section: "Free Video Lectures", name: "MADE EASY", desc: "Free YouTube playlists and sample lectures from a long-running coaching institute.", url: "https://www.madeeasy.in", type: "Video", difficulty: "Intermediate" },
  { id: "vid4", section: "Free Video Lectures", name: "Unacademy GATE", desc: "Free live classes and preview lectures from top-rated GATE educators.", url: "https://unacademy.com", type: "Video", difficulty: "Intermediate" },
  { id: "vid5", section: "Free Video Lectures", name: "Kreatryx (KT)", desc: "Focused video content for EE, ECE and Instrumentation aspirants.", url: "https://www.kreatryx.com", type: "Video", difficulty: "Intermediate", branches: ["EE", "ECE"] },

  // ---------------- Notes & Study Material ----------------
  { id: "note1", section: "Notes & Study Material", name: "PhysicsWallah (PW)", desc: "Structured free blog notes and exam guides covering GATE subjects and strategy.", url: "https://www.pw.live/gate", type: "Notes", difficulty: "Beginner" },
  { id: "note2", section: "Notes & Study Material", name: "TutorialsDuniya", desc: "Semester and GATE-aligned handwritten-style notes for core engineering subjects.", url: "https://www.google.com/search?q=TutorialsDuniya+GATE+notes", type: "Notes", difficulty: "Beginner" },
  { id: "note3", section: "Notes & Study Material", name: "GATE Overflow", desc: "The most active CSE community — solved PYQs, discussions and a free downloadable book.", url: "https://gateoverflow.in", type: "Notes", difficulty: "Advanced", branches: ["CSE", "IT"] },
  { id: "note4", section: "Notes & Study Material", name: "Ravindrababu Ravula (RBR)", desc: "Official site and channel of RBR — well-known CSE educator; notes referenced via his lectures.", url: "https://ravindrababuravula.in", type: "Notes", difficulty: "Advanced", branches: ["CSE", "IT"] },
  { id: "note5", section: "Notes & Study Material", name: "GATE Academy Notes", desc: "PDF notes shared alongside GATE ACADEMY's video lectures for most branches.", url: "https://www.youtube.com/@gate_academy", type: "Notes", difficulty: "Intermediate" },
  { id: "note6", section: "Notes & Study Material", name: "Public GitHub GATE repositories", desc: "Community-curated, openly licensed notes and resource lists — search reveals many active repos.", url: "https://github.com/search?q=GATE+exam+preparation+notes&type=repositories", type: "Notes", difficulty: "Intermediate" },

  // ---------------- Previous Year Questions ----------------
  { id: "pyq1", section: "Previous Year Questions", name: "Official GATE PYQ papers", desc: "Authentic archived question papers, direct from the organizing institute.", url: "https://www.google.com/search?q=GATE+previous+year+question+papers+official", type: "PYQ", difficulty: "Intermediate" },
  { id: "pyq2", section: "Previous Year Questions", name: "Official answer keys", desc: "Released alongside each paper — always cross-check your practice against these.", url: "https://www.google.com/search?q=GATE+official+answer+key", type: "PYQ", difficulty: "Intermediate" },
  { id: "pyq3", section: "Previous Year Questions", name: "RBR PYQ walkthroughs", desc: "Previous-year questions solved and explained on RBR's channel.", url: "https://www.youtube.com/@ravindrababu_ravula", type: "PYQ", difficulty: "Advanced", branches: ["CSE", "IT"] },
  { id: "pyq4", section: "Previous Year Questions", name: "Topic-wise PYQs (in this app)", desc: "Open any subject's PYQ tab to practice questions grouped by topic.", internal: "subjects", type: "PYQ", difficulty: "Intermediate" },
  { id: "pyq5", section: "Previous Year Questions", name: "Year-wise PYQs (in this app)", desc: "Browse practice sets organized by year for your branch.", internal: "pyq", type: "PYQ", difficulty: "Intermediate" },

  // ---------------- Mock Tests & Practice ----------------
  { id: "mock1", section: "Mock Tests & Practice", name: "BYJU'S Exam Prep", desc: "Free mock tests, quizzes and solved papers for GATE and other government exams.", url: "https://byjusexamprep.com", type: "Mock Test", difficulty: "Intermediate" },
  { id: "mock2", section: "Mock Tests & Practice", name: "Testbook", desc: "Large bank of free mock tests and topic-wise practice for GATE.", url: "https://testbook.com", type: "Mock Test", difficulty: "Intermediate" },
  { id: "mock3", section: "Mock Tests & Practice", name: "Topic-wise MCQs (in this app)", desc: "Practice tab inside every subject page.", internal: "subjects", type: "Mock Test", difficulty: "Beginner" },
  { id: "mock4", section: "Mock Tests & Practice", name: "Daily Quizzes (in this app)", desc: "A fresh set of 10–20 MCQs every day, with revision built in.", internal: "daily", type: "Mock Test", difficulty: "Beginner" },
  { id: "mock5", section: "Mock Tests & Practice", name: "Subject-wise Tests (in this app)", desc: "Jump into any subject to test yourself on just that topic.", internal: "subjects", type: "Mock Test", difficulty: "Intermediate" },
  { id: "mock6", section: "Mock Tests & Practice", name: "Full-length mock tests", desc: "Timed, exam-pattern mocks from established test-prep platforms.", url: "https://www.google.com/search?q=GATE+free+full+length+mock+test", type: "Mock Test", difficulty: "Advanced" },

  // ---------------- Aptitude Resources ----------------
  { id: "apt1", section: "Aptitude Resources", name: "IndiaBIX", desc: "Deep bank of Quantitative Aptitude and Logical Reasoning practice questions.", url: "https://www.indiabix.com", type: "Notes", difficulty: "Beginner" },
  { id: "apt2", section: "Aptitude Resources", name: "GATE Aptitude PYQs (in this app)", desc: "Practice previous-year style General Aptitude questions.", internal: "aptitude", type: "PYQ", difficulty: "Intermediate" },
  { id: "apt3", section: "Aptitude Resources", name: "Daily Aptitude Quiz (in this app)", desc: "Aptitude questions are mixed into your daily set automatically.", internal: "daily", type: "Mock Test", difficulty: "Beginner" },
  { id: "apt4", section: "Aptitude Resources", name: "Aptitude formula sheets", desc: "Quick-reference formula PDFs for ratios, time-speed-distance, percentages and more.", url: "https://www.google.com/search?q=GATE+quantitative+aptitude+formula+sheet+pdf", type: "Formula Sheet", difficulty: "Beginner" },

  // ---------------- Additional Learning Resources ----------------
  { id: "add1", section: "Additional Learning Resources", name: "EduRev", desc: "Community-driven notes, tests and video content across all GATE branches.", url: "https://edurev.in", type: "Notes", difficulty: "Beginner" },
  { id: "add2", section: "Additional Learning Resources", name: "Careers360", desc: "Exam news, cutoffs, syllabus breakdowns and comparison articles.", url: "https://www.careers360.com", type: "Official", difficulty: "Beginner" },
  { id: "add3", section: "Additional Learning Resources", name: "GO Classes", desc: "Free courses, weekly quizzes and doubt support, closely tied to GATE Overflow.", url: "https://www.goclasses.in", type: "Video", difficulty: "Advanced", branches: ["CSE", "IT"] },
  { id: "add4", section: "Additional Learning Resources", name: "Knowledge Gate AI", desc: "CS-focused lecture archive and AI-powered learning tools for GATE and placements.", url: "https://www.knowledgegate.ai", type: "Video", difficulty: "Intermediate", branches: ["CSE", "IT"] },
];

const RESOURCE_SECTIONS = [
  "Official Resources", "Free Video Lectures", "Notes & Study Material",
  "Previous Year Questions", "Mock Tests & Practice", "Aptitude Resources",
  "Additional Learning Resources",
];

function resourceSearchLink(name, subject, branch) {
  return "https://www.youtube.com/results?search_query=" + encodeURIComponent(`${name} ${subject} GATE ${branch}`);
}

/* ============================================================
   HELPERS
   ============================================================ */
function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function seededShuffle(arr, seed) {
  const rng = mulberry32(seed);
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function todayStr() {
  return new Date().toISOString().slice(0, 10);
}
function dateSeed() {
  return parseInt(todayStr().replace(/-/g, ""), 10);
}
function addDays(dateStr, n) {
  const d = new Date(dateStr + "T00:00:00");
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}
function daysDiff(a, b) {
  return Math.round((new Date(b) - new Date(a)) / 86400000);
}
function youtubeSearch(q) {
  return "https://www.youtube.com/results?search_query=" + encodeURIComponent(q);
}

/* Map every question id -> { subject, branch } so we can turn raw
   attempt history into subject-level accuracy for recommendations. */
function buildQuestionIndex() {
  const idx = {};
  DAILY_BANK.forEach((q) => { idx[q.id] = { subject: q.subject, branches: q.branches }; });
  PYQ_BANK.forEach((q) => { idx[q.id] = { subject: q.subject, branches: [q.branch] }; });
  APTITUDE_BANK.forEach((q) => { idx[q.id] = { subject: q.category, branches: null }; });
  return idx;
}
const QUESTION_INDEX = buildQuestionIndex();

function subjectPerformance(attempts) {
  const bySubject = {};
  Object.entries(attempts).forEach(([id, a]) => {
    const meta = QUESTION_INDEX[id];
    if (!meta) return;
    const s = meta.subject;
    if (!bySubject[s]) bySubject[s] = { correct: 0, total: 0 };
    bySubject[s].total += 1;
    if (a.correct) bySubject[s].correct += 1;
  });
  return bySubject;
}

function buildRecommendations(state) {
  const perf = subjectPerformance(state.attempts);
  const branch = state.branch;
  const entries = Object.entries(perf).map(([subject, s]) => ({
    subject, accuracy: s.total ? s.correct / s.total : 1, total: s.total,
  }));
  entries.sort((a, b) => a.accuracy - b.accuracy);
  const weak = entries.find((e) => e.total >= 2 && e.accuracy < 0.7);
  const focusSubject = weak ? weak.subject : (SUBJECTS_BY_BRANCH[branch] || [])[0];
  const dueCount = Object.values(state.attempts).filter((a) => a.nextReview && a.nextReview <= todayStr()).length;
  const hasStudiedToday = state.streak.lastDate === todayStr();

  return [
    {
      icon: "video", label: "Video to watch", title: `${focusSubject} — pick a channel and search`,
      detail: weak ? `Your accuracy in ${focusSubject} is under 70% — a refresher video should help.` : `Get a solid grounding in ${focusSubject} before drilling questions.`,
      action: { type: "external", url: resourceSearchLink("Gate Smashers OR GATE ACADEMY", focusSubject, branch) },
    },
    {
      icon: "notes", label: "Notes to read", title: `${focusSubject} — subject notes`,
      detail: "Quick concept refresher plus focus tips inside the app.",
      action: { type: "internal", screen: "subjects" },
    },
    {
      icon: "pyq", label: "PYQs to solve", title: dueCount > 0 ? `${dueCount} question${dueCount > 1 ? "s" : ""} due for revision` : `${focusSubject} previous-year practice`,
      detail: dueCount > 0 ? "These are questions you missed before — solve them again to lock them in." : "Reinforce the concept with exam-style questions.",
      action: { type: "internal", screen: "daily" },
    },
    {
      icon: "mock", label: "Mock test", title: "Take a subject-wise test",
      detail: `Test yourself on ${focusSubject} under light time pressure.`,
      action: { type: "internal", screen: "subjects" },
    },
    {
      icon: "daily", label: "Daily quiz", title: hasStudiedToday ? "Already done for today — nice work" : "You haven't done today's set yet",
      detail: hasStudiedToday ? "Come back tomorrow to keep your streak alive." : "Keep your streak alive with today's 10–20 questions.",
      action: { type: "internal", screen: "daily" },
    },
    {
      icon: "formula", label: "Formula sheet", title: "Quick-reference formulas",
      detail: "A fast recap before solving numerical-heavy questions.",
      action: { type: "external", url: "https://www.google.com/search?q=" + encodeURIComponent(`${focusSubject} GATE formula sheet pdf`) },
    },
  ];
}

const STORAGE_KEY = "gate-prep-v1";
const DEFAULT_STATE = {
  branch: null,
  theme: "light",
  streak: { count: 0, lastDate: null },
  stats: { solved: 0, correct: 0 },
  attempts: {}, // id -> { correct, lastAnswered, nextReview }
};

async function loadState() {
  try {
    const res = await window.storage.get(STORAGE_KEY, false);
    if (res && res.value) return { ...DEFAULT_STATE, ...JSON.parse(res.value) };
  } catch (e) { /* not found yet */ }
  return { ...DEFAULT_STATE };
}
async function saveState(state) {
  try {
    await window.storage.set(STORAGE_KEY, JSON.stringify(state), false);
  } catch (e) { console.error("Storage save failed", e); }
}

/* ============================================================
   SMALL UI PIECES
   ============================================================ */
function Bubble({ label, state, onClick, t }) {
  // state: 'idle' | 'selected' | 'correct' | 'wrong'
  let bg = "transparent", border = t.border, color = t.ink, textColor = t.inkMuted;
  if (state === "selected") { bg = t.accent; border = t.accent; color = "#fff"; }
  if (state === "correct") { bg = t.correct; border = t.correct; color = "#fff"; }
  if (state === "wrong") { bg = t.wrong; border = t.wrong; color = "#fff"; }
  return (
    <div
      style={{
        width: 34, height: 34, borderRadius: "50%", border: `2px solid ${border}`,
        backgroundColor: bg, color, display: "flex", alignItems: "center",
        justifyContent: "center", fontFamily: FONT_MONO, fontWeight: 600, fontSize: 14,
        flexShrink: 0, transition: "all 0.15s ease",
      }}
    >
      {state === "correct" ? <Check size={16} /> : state === "wrong" ? <X size={16} /> : label}
    </div>
  );
}

function OptionRow({ letter, text, idx, selected, showResult, correctIdx, onSelect, t }) {
  const isSelected = selected === idx;
  const isCorrect = idx === correctIdx;
  let bubbleState = "idle";
  if (showResult) {
    if (isCorrect) bubbleState = "correct";
    else if (isSelected && !isCorrect) bubbleState = "wrong";
  } else if (isSelected) bubbleState = "selected";

  let rowBg = t.surface, rowBorder = t.border;
  if (showResult && isCorrect) { rowBg = t.correctSoft; rowBorder = t.correct; }
  else if (showResult && isSelected && !isCorrect) { rowBg = t.wrongSoft; rowBorder = t.wrong; }
  else if (!showResult && isSelected) { rowBg = t.accentSoft; rowBorder = t.accent; }

  return (
    <button
      onClick={() => !showResult && onSelect(idx)}
      disabled={showResult}
      style={{
        display: "flex", alignItems: "center", gap: 12, width: "100%",
        padding: "12px 14px", borderRadius: 14, border: `1.5px solid ${rowBorder}`,
        backgroundColor: rowBg, textAlign: "left", cursor: showResult ? "default" : "pointer",
        marginBottom: 10, fontFamily: FONT_BODY,
      }}
    >
      <Bubble label={letter} state={bubbleState} t={t} />
      <span style={{ fontSize: 14.5, color: t.ink, lineHeight: 1.4 }}>{text}</span>
    </button>
  );
}

function Card({ children, onClick, t, style }) {
  return (
    <div
      onClick={onClick}
      style={{
        backgroundColor: t.surface, border: `1px solid ${t.border}`, borderRadius: 16,
        padding: 16, boxShadow: t.shadow, cursor: onClick ? "pointer" : "default", ...style,
      }}
    >
      {children}
    </div>
  );
}

function TopBar({ title, onBack, t, right }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "16px 18px 12px", position: "sticky", top: 0, backgroundColor: t.bg, zIndex: 10,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        {onBack && (
          <button onClick={onBack} style={{ background: "none", border: "none", cursor: "pointer", color: t.ink, padding: 4 }}>
            <ChevronLeft size={22} />
          </button>
        )}
        <h1 style={{ fontFamily: FONT_DISPLAY, fontWeight: 600, fontSize: 19, color: t.ink, margin: 0 }}>{title}</h1>
      </div>
      {right}
    </div>
  );
}

function ProgressRing({ pct, t, size = 84, label, sublabel }) {
  const r = (size - 10) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (pct / 100) * circ;
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={r} stroke={t.border} strokeWidth={8} fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={t.accent} strokeWidth={8} fill="none"
          strokeDasharray={circ} strokeDashoffset={offset} strokeLinecap="round" />
      </svg>
      <div style={{
        position: "absolute", inset: 0, display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center",
      }}>
        <span style={{ fontFamily: FONT_MONO, fontWeight: 600, fontSize: 17, color: t.ink }}>{label}</span>
        {sublabel && <span style={{ fontSize: 9, color: t.inkMuted }}>{sublabel}</span>}
      </div>
    </div>
  );
}

/* ============================================================
   QUIZ RUNNER (shared by Daily / PYQ / Aptitude)
   ============================================================ */
function QuizRunner({ questions, t, onAnswer, tagLabel, emptyText, onFinishBack }) {
  const [idx, setIdx] = useState(0);
  const [selected, setSelected] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [sessionCorrect, setSessionCorrect] = useState(0);
  const [finished, setFinished] = useState(false);
  const letters = ["A", "B", "C", "D"];

  if (!questions || questions.length === 0) {
    return (
      <div style={{ padding: 24, textAlign: "center", color: t.inkMuted }}>
        <p>{emptyText || "No questions available right now."}</p>
      </div>
    );
  }

  if (finished) {
    const pct = Math.round((sessionCorrect / questions.length) * 100);
    return (
      <div style={{ padding: "40px 20px", textAlign: "center" }}>
        <Award size={40} color={t.accent} style={{ marginBottom: 12 }} />
        <h2 style={{ fontFamily: FONT_DISPLAY, fontSize: 22, color: t.ink, margin: "0 0 6px" }}>Set complete</h2>
        <p style={{ color: t.inkMuted, marginBottom: 20 }}>
          You got {sessionCorrect} of {questions.length} correct ({pct}%).
        </p>
        <button onClick={onFinishBack} style={{
          backgroundColor: t.accent, color: "#fff", border: "none", borderRadius: 12,
          padding: "12px 22px", fontFamily: FONT_BODY, fontWeight: 600, fontSize: 14, cursor: "pointer",
        }}>Back</button>
      </div>
    );
  }

  const question = questions[idx];

  const handleSelect = (i) => {
    setSelected(i);
    setShowResult(true);
    const isCorrect = i === question.correct;
    if (isCorrect) setSessionCorrect((c) => c + 1);
    onAnswer(question, isCorrect);
  };

  const handleNext = () => {
    if (idx + 1 >= questions.length) { setFinished(true); return; }
    setIdx(idx + 1);
    setSelected(null);
    setShowResult(false);
  };

  return (
    <div style={{ padding: "0 18px 24px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <span style={{ fontFamily: FONT_MONO, fontSize: 12.5, color: t.inkMuted }}>
          Question {idx + 1} / {questions.length}
        </span>
        {tagLabel && (
          <span style={{
            fontSize: 11, color: t.accent, backgroundColor: t.accentSoft, padding: "3px 10px",
            borderRadius: 20, fontFamily: FONT_BODY, fontWeight: 600,
          }}>{tagLabel(question)}</span>
        )}
      </div>

      <div style={{ height: 4, borderRadius: 4, backgroundColor: t.surfaceAlt, marginBottom: 18, overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${((idx) / questions.length) * 100}%`, backgroundColor: t.accent, transition: "width .2s" }} />
      </div>

      <Card t={t} style={{ marginBottom: 16 }}>
        <p style={{ fontSize: 16, color: t.ink, lineHeight: 1.5, margin: 0, fontFamily: FONT_BODY }}>{question.q}</p>
      </Card>

      {question.options.map((opt, i) => (
        <OptionRow key={i} letter={letters[i]} text={opt} idx={i} selected={selected}
          showResult={showResult} correctIdx={question.correct} onSelect={handleSelect} t={t} />
      ))}

      {showResult && (
        <Card t={t} style={{
          marginTop: 8, backgroundColor: selected === question.correct ? t.correctSoft : t.wrongSoft,
          border: `1px solid ${selected === question.correct ? t.correct : t.wrong}`,
        }}>
          <p style={{
            margin: "0 0 6px", fontWeight: 700, fontSize: 13.5,
            color: selected === question.correct ? t.correct : t.wrong, fontFamily: FONT_BODY,
          }}>
            {selected === question.correct ? "Correct" : "Not quite"}
          </p>
          <p style={{ margin: 0, fontSize: 13.5, color: t.ink, lineHeight: 1.5 }}>{question.explanation}</p>
        </Card>
      )}

      {showResult && (
        <button onClick={handleNext} style={{
          marginTop: 16, width: "100%", backgroundColor: t.ink, color: t.bg, border: "none",
          borderRadius: 12, padding: "13px", fontFamily: FONT_BODY, fontWeight: 600, fontSize: 14.5,
          cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
        }}>
          {idx + 1 >= questions.length ? "Finish" : "Next question"} <ArrowRight size={16} />
        </button>
      )}
    </div>
  );
}

/* ============================================================
   SCREENS
   ============================================================ */
function BranchSelectScreen({ onSelect, t }) {
  return (
    <div style={{ minHeight: "100vh", backgroundColor: t.bg, display: "flex", flexDirection: "column", padding: "60px 22px 30px" }}>
      <GraduationCap size={34} color={t.accent} />
      <h1 style={{ fontFamily: FONT_DISPLAY, fontSize: 26, color: t.ink, margin: "16px 0 6px", fontWeight: 700 }}>
        GATE Prep
      </h1>
      <p style={{ color: t.inkMuted, fontSize: 14.5, marginBottom: 28, lineHeight: 1.5 }}>
        Pick your branch to load daily practice, previous-year questions and notes tailored to your syllabus.
      </p>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {BRANCHES.map((b) => (
          <button key={b.id} onClick={() => onSelect(b.id)} style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            backgroundColor: t.surface, border: `1.5px solid ${t.border}`, borderRadius: 14,
            padding: "16px 18px", cursor: "pointer", textAlign: "left",
          }}>
            <div>
              <div style={{ fontFamily: FONT_MONO, fontWeight: 600, fontSize: 15, color: t.accent }}>{b.short}</div>
              <div style={{ fontSize: 13, color: t.inkMuted, marginTop: 2 }}>{b.name}</div>
            </div>
            <ChevronRight size={18} color={t.inkMuted} />
          </button>
        ))}
      </div>
    </div>
  );
}

function HomeScreen({ state, t, go }) {
  const branchInfo = BRANCHES.find((b) => b.id === state.branch);
  const accuracy = state.stats.solved ? Math.round((state.stats.correct / state.stats.solved) * 100) : 0;
  const items = [
    { key: "daily", label: "Daily Questions", desc: "Today's practice set", icon: Zap },
    { key: "subjects", label: "Subjects", desc: "Notes, practice & videos", icon: BookOpen },
    { key: "pyq", label: "Previous Year Questions", desc: "By subject and year", icon: FileText },
    { key: "aptitude", label: "General Aptitude", desc: "Quant, reasoning, English", icon: ListChecks },
    { key: "progress", label: "Progress", desc: "Streak & accuracy", icon: TrendingUp },
    { key: "resources", label: "Free Resources", desc: "NPTEL, GfG & more", icon: ExternalLink },
  ];
  return (
    <div style={{ padding: "20px 18px 100px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
        <div>
          <p style={{ color: t.inkMuted, fontSize: 13, margin: 0 }}>Preparing for</p>
          <h1 style={{ fontFamily: FONT_DISPLAY, fontSize: 22, color: t.ink, margin: "2px 0 0", fontWeight: 700 }}>
            GATE {branchInfo?.short}
          </h1>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6, backgroundColor: t.surfaceAlt, padding: "8px 12px", borderRadius: 20 }}>
          <Flame size={16} color={t.accent} />
          <span style={{ fontFamily: FONT_MONO, fontWeight: 600, fontSize: 13, color: t.ink }}>{state.streak.count}</span>
        </div>
      </div>

      <Card t={t} style={{ marginBottom: 18, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <p style={{ margin: 0, fontSize: 12.5, color: t.inkMuted }}>Overall accuracy</p>
          <p style={{ margin: "4px 0 0", fontFamily: FONT_MONO, fontSize: 22, fontWeight: 600, color: t.ink }}>{accuracy}%</p>
          <p style={{ margin: "2px 0 0", fontSize: 12, color: t.inkMuted }}>{state.stats.solved} questions solved</p>
        </div>
        <ProgressRing pct={accuracy} t={t} size={64} label={`${accuracy}%`} />
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {items.map(({ key, label, desc, icon: Icon }) => (
          <Card key={key} t={t} onClick={() => go(key)} style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10, backgroundColor: t.accentSoft,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <Icon size={18} color={t.accent} />
            </div>
            <div>
              <p style={{ margin: 0, fontWeight: 600, fontSize: 13.5, color: t.ink, fontFamily: FONT_BODY }}>{label}</p>
              <p style={{ margin: "2px 0 0", fontSize: 11.5, color: t.inkMuted }}>{desc}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function buildDailySet(branch, attempts) {
  const today = todayStr();
  const pool = DAILY_BANK.filter((q) => q.branches.includes(branch));
  const due = pool.filter((q) => {
    const a = attempts[q.id];
    return a && a.nextReview && a.nextReview <= today;
  });
  const shuffled = seededShuffle(pool, dateSeed());
  const fresh = shuffled.filter((q) => !due.find((d) => d.id === q.id));
  const combined = [...due, ...fresh].slice(0, Math.min(20, Math.max(10, pool.length)));
  return combined;
}

function DailyScreen({ state, t, onAnswer, onBack }) {
  const questions = useMemo(() => buildDailySet(state.branch, state.attempts), [state.branch]);
  return (
    <div>
      <TopBar title="Daily Questions" onBack={onBack} t={t} />
      <p style={{ padding: "0 18px", color: t.inkMuted, fontSize: 12.5, marginTop: -8, marginBottom: 4 }}>
        A fresh mix each day, plus a few earlier misses for revision.
      </p>
      <QuizRunner
        questions={questions}
        t={t}
        onAnswer={(q, correct) => onAnswer(q, correct)}
        tagLabel={(q) => q.subject}
        onFinishBack={onBack}
      />
    </div>
  );
}

function subjectNote(subject) {
  const notes = {
    "Engineering Mathematics": "Covers linear algebra, calculus, probability and differential equations — high-weightage across every branch. Master standard formulas and speed on numericals.",
    "General Aptitude": "A guaranteed 15 marks in every GATE paper. Quant, reasoning and English questions are usually shorter and quicker to solve than core subject ones.",
  };
  return notes[subject] || `Core concepts, standard derivations and problem-solving techniques for ${subject}, aligned with the GATE syllabus. Focus on frequently repeated question types and formula-based numericals.`;
}

function SubjectsScreen({ state, t, onOpenSubject, onBack }) {
  const subjects = SUBJECTS_BY_BRANCH[state.branch] || [];
  return (
    <div>
      <TopBar title="Subjects" onBack={onBack} t={t} />
      <div style={{ padding: "4px 18px 24px", display: "flex", flexDirection: "column", gap: 10 }}>
        {subjects.map((s) => (
          <Card key={s} t={t} onClick={() => onOpenSubject(s)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ fontSize: 14.5, fontWeight: 600, color: t.ink, fontFamily: FONT_BODY }}>{s}</span>
            <ChevronRight size={16} color={t.inkMuted} />
          </Card>
        ))}
      </div>
    </div>
  );
}

function SubjectDetailScreen({ subject, state, t, onAnswer, onBack }) {
  const [tab, setTab] = useState("notes");
  const practice = DAILY_BANK.filter((q) => q.branches.includes(state.branch) && q.subject === subject);
  const pyq = PYQ_BANK.filter((q) => q.branch === state.branch && q.subject === subject);
  const videoChannels = ["Gate Smashers", "NPTEL", "MADE EASY"];
  const tabs = [
    { id: "notes", label: "Notes" },
    { id: "practice", label: "Practice" },
    { id: "pyq", label: "PYQ" },
    { id: "videos", label: "Videos" },
  ];
  return (
    <div>
      <TopBar title={subject} onBack={onBack} t={t} />
      <div style={{ display: "flex", gap: 6, padding: "0 18px 14px", overflowX: "auto" }}>
        {tabs.map((tb) => (
          <button key={tb.id} onClick={() => setTab(tb.id)} style={{
            padding: "7px 14px", borderRadius: 20, border: "none", cursor: "pointer",
            backgroundColor: tab === tb.id ? t.accent : t.surfaceAlt,
            color: tab === tb.id ? "#fff" : t.inkMuted, fontFamily: FONT_BODY, fontWeight: 600,
            fontSize: 12.5, whiteSpace: "nowrap",
          }}>{tb.label}</button>
        ))}
      </div>

      {tab === "notes" && (
        <div style={{ padding: "0 18px 24px" }}>
          <Card t={t}>
            <p style={{ margin: 0, fontSize: 14, color: t.ink, lineHeight: 1.6 }}>{subjectNote(subject)}</p>
          </Card>
          <p style={{ margin: "16px 0 8px", fontSize: 12.5, fontWeight: 700, color: t.inkMuted, textTransform: "uppercase", letterSpacing: 0.4 }}>What to focus on</p>
          {["Learn the weightage — check recent papers to see how many marks this subject typically carries.",
            "Build a formula sheet and revise it before every practice set.",
            "Work through previous-year questions early; GATE repeats concepts often."].map((tip, i) => (
            <Card key={i} t={t} style={{ marginBottom: 8, padding: "12px 14px" }}>
              <p style={{ margin: 0, fontSize: 13, color: t.ink }}>{tip}</p>
            </Card>
          ))}
        </div>
      )}

      {tab === "practice" && (
        <QuizRunner questions={practice} t={t} onAnswer={onAnswer}
          emptyText="No practice questions for this subject yet — check back soon." onFinishBack={onBack} />
      )}

      {tab === "pyq" && (
        <QuizRunner questions={pyq} t={t} onAnswer={onAnswer}
          tagLabel={(q) => q.year} emptyText="No previous-year style questions for this subject yet."
          onFinishBack={onBack} />
      )}

      {tab === "videos" && (
        <div style={{ padding: "0 18px 24px", display: "flex", flexDirection: "column", gap: 10 }}>
          {videoChannels.map((ch) => (
            <a key={ch} href={youtubeSearch(`${subject} GATE ${state.branch} ${ch}`)} target="_blank" rel="noopener noreferrer" style={{ textDecoration: "none" }}>
              <Card t={t} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <Youtube size={18} color={t.accent} />
                  <span style={{ fontSize: 13.5, color: t.ink, fontFamily: FONT_BODY }}>{ch} — {subject}</span>
                </div>
                <ExternalLink size={14} color={t.inkMuted} />
              </Card>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

function PYQScreen({ state, t, onAnswer, onBack }) {
  const [subject, setSubject] = useState(null);
  const [year, setYear] = useState(null);
  const branchPyq = PYQ_BANK.filter((q) => q.branch === state.branch);
  const subjects = [...new Set(branchPyq.map((q) => q.subject))];

  if (!subject) {
    return (
      <div>
        <TopBar title="Previous Year Questions" onBack={onBack} t={t} />
        <p style={{ padding: "0 18px", color: t.inkMuted, fontSize: 12.5, marginTop: -8, marginBottom: 12 }}>
          Original practice questions modeled on the GATE pattern — see Free Resources for official archived papers.
        </p>
        <div style={{ padding: "0 18px 24px", display: "flex", flexDirection: "column", gap: 10 }}>
          {subjects.length === 0 && <p style={{ color: t.inkMuted }}>No practice sets yet for this branch.</p>}
          {subjects.map((s) => (
            <Card key={s} t={t} onClick={() => setSubject(s)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ fontSize: 14, fontWeight: 600, color: t.ink }}>{s}</span>
              <ChevronRight size={16} color={t.inkMuted} />
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const years = [...new Set(branchPyq.filter((q) => q.subject === subject).map((q) => q.year))].sort((a, b) => b - a);

  if (!year) {
    return (
      <div>
        <TopBar title={subject} onBack={() => setSubject(null)} t={t} />
        <div style={{ padding: "0 18px 24px", display: "flex", flexDirection: "column", gap: 10 }}>
          {years.map((y) => (
            <Card key={y} t={t} onClick={() => setYear(y)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ fontFamily: FONT_MONO, fontSize: 14, fontWeight: 600, color: t.ink }}>{y}</span>
              <ChevronRight size={16} color={t.inkMuted} />
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const questions = branchPyq.filter((q) => q.subject === subject && q.year === year);
  return (
    <div>
      <TopBar title={`${subject} · ${year}`} onBack={() => setYear(null)} t={t} />
      <QuizRunner questions={questions} t={t} onAnswer={onAnswer} onFinishBack={() => setYear(null)} />
    </div>
  );
}

function AptitudeScreen({ t, onAnswer, onBack }) {
  const [category, setCategory] = useState(null);
  if (!category) {
    return (
      <div>
        <TopBar title="General Aptitude" onBack={onBack} t={t} />
        <div style={{ padding: "0 18px 24px", display: "flex", flexDirection: "column", gap: 10 }}>
          {APTITUDE_CATEGORIES.map((c) => (
            <Card key={c} t={t} onClick={() => setCategory(c)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ fontSize: 14.5, fontWeight: 600, color: t.ink }}>{c}</span>
              <ChevronRight size={16} color={t.inkMuted} />
            </Card>
          ))}
        </div>
      </div>
    );
  }
  const questions = APTITUDE_BANK.filter((q) => q.category === category);
  return (
    <div>
      <TopBar title={category} onBack={() => setCategory(null)} t={t} />
      <QuizRunner questions={questions} t={t} onAnswer={onAnswer} onFinishBack={() => setCategory(null)} />
    </div>
  );
}

function ProgressScreen({ state, t, onBack }) {
  const accuracy = state.stats.solved ? Math.round((state.stats.correct / state.stats.solved) * 100) : 0;
  const dueCount = Object.values(state.attempts).filter((a) => a.nextReview && a.nextReview <= todayStr()).length;
  return (
    <div>
      <TopBar title="Progress" onBack={onBack} t={t} />
      <div style={{ padding: "4px 18px 24px" }}>
        <Card t={t} style={{ display: "flex", justifyContent: "space-around", marginBottom: 14, textAlign: "center" }}>
          <ProgressRing pct={accuracy} t={t} label={`${accuracy}%`} sublabel="accuracy" />
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 4 }}>
            <Flame size={26} color={t.accent} />
            <span style={{ fontFamily: FONT_MONO, fontWeight: 700, fontSize: 20, color: t.ink }}>{state.streak.count}</span>
            <span style={{ fontSize: 11, color: t.inkMuted }}>day streak</span>
          </div>
        </Card>

        <Card t={t} style={{ marginBottom: 10, display: "flex", alignItems: "center", gap: 12 }}>
          <Target size={20} color={t.accent} />
          <div>
            <p style={{ margin: 0, fontSize: 13, color: t.inkMuted }}>Questions solved</p>
            <p style={{ margin: "2px 0 0", fontFamily: FONT_MONO, fontWeight: 700, fontSize: 17, color: t.ink }}>{state.stats.solved}</p>
          </div>
        </Card>

        <Card t={t} style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <RotateCcw size={20} color={t.accent} />
          <div>
            <p style={{ margin: 0, fontSize: 13, color: t.inkMuted }}>Due for revision today</p>
            <p style={{ margin: "2px 0 0", fontFamily: FONT_MONO, fontWeight: 700, fontSize: 17, color: t.ink }}>{dueCount}</p>
          </div>
        </Card>
      </div>
    </div>
  );
}

const REC_ICONS = { video: Youtube, notes: StickyNote, pyq: ClipboardList, mock: ListChecks, daily: Zap, formula: Calculator };

function RecommendationCard({ rec, t, go }) {
  const Icon = REC_ICONS[rec.icon] || Sparkles;
  const handleClick = () => {
    if (rec.action.type === "internal") go(rec.action.screen);
    else window.open(rec.action.url, "_blank", "noopener,noreferrer");
  };
  return (
    <div onClick={handleClick} style={{
      minWidth: 210, backgroundColor: t.surface, border: `1px solid ${t.border}`, borderRadius: 14,
      padding: 14, cursor: "pointer", flexShrink: 0,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <div style={{ width: 28, height: 28, borderRadius: 8, backgroundColor: t.accentSoft, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Icon size={14} color={t.accent} />
        </div>
        <span style={{ fontSize: 10.5, fontWeight: 700, color: t.accent, textTransform: "uppercase", letterSpacing: 0.4 }}>{rec.label}</span>
      </div>
      <p style={{ margin: 0, fontSize: 13, fontWeight: 600, color: t.ink, lineHeight: 1.35 }}>{rec.title}</p>
      <p style={{ margin: "4px 0 0", fontSize: 11.5, color: t.inkMuted, lineHeight: 1.4 }}>{rec.detail}</p>
    </div>
  );
}

function ResourceRow({ r, t, go, branch, currentSubject }) {
  const [expanded, setExpanded] = useState(false);
  const subjects = SUBJECTS_BY_BRANCH[branch] || [];
  const canExpand = r.type === "Video" && !r.internal;

  const handleOpen = () => {
    if (r.internal) go(r.internal);
    else window.open(r.url, "_blank", "noopener,noreferrer");
  };

  return (
    <Card t={t} style={{ padding: 0, overflow: "hidden" }}>
      <div onClick={handleOpen} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: 16, cursor: "pointer" }}>
        <div style={{ paddingRight: 10 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 3 }}>
            <p style={{ margin: 0, fontSize: 14, fontWeight: 600, color: t.ink }}>{r.name}</p>
            <span style={{ fontSize: 9.5, fontWeight: 700, color: t.accent, backgroundColor: t.accentSoft, padding: "2px 7px", borderRadius: 20 }}>{r.type}</span>
          </div>
          <p style={{ margin: 0, fontSize: 12, color: t.inkMuted, lineHeight: 1.4 }}>{r.desc}</p>
        </div>
        {r.internal ? <ChevronRight size={16} color={t.inkMuted} style={{ flexShrink: 0 }} /> : <ExternalLink size={16} color={t.inkMuted} style={{ flexShrink: 0 }} />}
      </div>
      {canExpand && (
        <div style={{ borderTop: `1px solid ${t.border}` }}>
          <button onClick={(e) => { e.stopPropagation(); setExpanded((x) => !x); }} style={{
            width: "100%", background: "none", border: "none", padding: "9px 16px", display: "flex",
            alignItems: "center", justifyContent: "space-between", cursor: "pointer", color: t.inkMuted, fontSize: 11.5, fontFamily: FONT_BODY,
          }}>
            Find a playlist for {currentSubject || "your subject"}
            {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>
          {expanded && (
            <div style={{ padding: "0 16px 14px", display: "flex", flexWrap: "wrap", gap: 6 }}>
              {subjects.map((s) => (
                <a key={s} href={resourceSearchLink(r.name, s, branch)} target="_blank" rel="noopener noreferrer" style={{ textDecoration: "none" }}>
                  <span style={{
                    fontSize: 11, color: t.ink, backgroundColor: t.surfaceAlt, padding: "5px 10px",
                    borderRadius: 20, display: "inline-block",
                  }}>{s}</span>
                </a>
              ))}
            </div>
          )}
        </div>
      )}
    </Card>
  );
}

function ResourcesScreen({ state, t, go, onBack }) {
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState(null);
  const [diffFilter, setDiffFilter] = useState(null);
  const branch = state.branch;
  const recommendations = useMemo(() => buildRecommendations(state), [state]);

  const filtered = RESOURCE_HUB.filter((r) => {
    if (r.branches && !r.branches.includes(branch)) return false;
    if (typeFilter && r.type !== typeFilter) return false;
    if (diffFilter && r.difficulty !== diffFilter) return false;
    if (query.trim()) {
      const q = query.toLowerCase();
      if (!r.name.toLowerCase().includes(q) && !r.desc.toLowerCase().includes(q) && !r.section.toLowerCase().includes(q)) return false;
    }
    return true;
  });

  return (
    <div>
      <TopBar title="Learning Resources" onBack={onBack} t={t} />

      <div style={{ padding: "0 18px 16px" }}>
        <div style={{
          display: "flex", alignItems: "center", gap: 8, backgroundColor: t.surface,
          border: `1px solid ${t.border}`, borderRadius: 12, padding: "10px 12px", marginBottom: 10,
        }}>
          <Search size={16} color={t.inkMuted} />
          <input
            value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search subject, topic or resource type"
            style={{ border: "none", outline: "none", background: "transparent", fontSize: 13.5, color: t.ink, width: "100%", fontFamily: FONT_BODY }}
          />
        </div>

        <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 6, paddingBottom: 2 }}>
          {RES_TYPES.map((ty) => (
            <button key={ty} onClick={() => setTypeFilter(typeFilter === ty ? null : ty)} style={{
              padding: "6px 12px", borderRadius: 20, border: "none", cursor: "pointer", whiteSpace: "nowrap",
              backgroundColor: typeFilter === ty ? t.accent : t.surfaceAlt, color: typeFilter === ty ? "#fff" : t.inkMuted,
              fontSize: 11.5, fontWeight: 600, fontFamily: FONT_BODY,
            }}>{ty}</button>
          ))}
        </div>
        <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 2 }}>
          {RES_DIFFICULTY.map((d) => (
            <button key={d} onClick={() => setDiffFilter(diffFilter === d ? null : d)} style={{
              padding: "6px 12px", borderRadius: 20, border: `1px solid ${diffFilter === d ? t.accent : t.border}`, cursor: "pointer", whiteSpace: "nowrap",
              backgroundColor: "transparent", color: diffFilter === d ? t.accent : t.inkMuted,
              fontSize: 11.5, fontWeight: 600, fontFamily: FONT_BODY,
            }}>{d}</button>
          ))}
        </div>
      </div>

      <div style={{ padding: "0 18px 10px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
          <Sparkles size={15} color={t.accent} />
          <p style={{ margin: 0, fontSize: 12.5, fontWeight: 700, color: t.ink }}>Recommended for you</p>
        </div>
        <div style={{ display: "flex", gap: 10, overflowX: "auto", paddingBottom: 6 }}>
          {recommendations.map((rec) => <RecommendationCard key={rec.label} rec={rec} t={t} go={go} />)}
        </div>
      </div>

      <div style={{ padding: "8px 18px 28px" }}>
        {RESOURCE_SECTIONS.map((section) => {
          const items = filtered.filter((r) => r.section === section);
          if (items.length === 0) return null;
          return (
            <div key={section} style={{ marginBottom: 18 }}>
              <p style={{ margin: "0 0 8px", fontSize: 12.5, fontWeight: 700, color: t.inkMuted, textTransform: "uppercase", letterSpacing: 0.4 }}>{section}</p>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {items.map((r) => <ResourceRow key={r.id} r={r} t={t} go={go} branch={branch} />)}
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && (
          <p style={{ textAlign: "center", color: t.inkMuted, fontSize: 13, marginTop: 20 }}>No resources match that search — try a different keyword or clear filters.</p>
        )}
        <p style={{ marginTop: 8, fontSize: 11, color: t.inkMuted, lineHeight: 1.5, textAlign: "center" }}>
          Only official or publicly available sources are linked here. This app doesn't host or copy anyone's copyrighted content.
        </p>
      </div>
    </div>
  );
}

function MoreScreen({ state, t, go, toggleTheme, changeBranch, onBack }) {
  return (
    <div>
      <TopBar title="More" onBack={onBack} t={t} />
      <div style={{ padding: "0 18px 24px", display: "flex", flexDirection: "column", gap: 10 }}>
        <Card t={t} onClick={() => go("aptitude")} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 14, fontWeight: 600, color: t.ink }}>General Aptitude</span>
          <ChevronRight size={16} color={t.inkMuted} />
        </Card>
        <Card t={t} onClick={() => go("progress")} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 14, fontWeight: 600, color: t.ink }}>Progress</span>
          <ChevronRight size={16} color={t.inkMuted} />
        </Card>
        <Card t={t} onClick={toggleTheme} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 14, fontWeight: 600, color: t.ink }}>
            {state.theme === "light" ? "Switch to dark mode" : "Switch to light mode"}
          </span>
          {state.theme === "light" ? <Moon size={16} color={t.inkMuted} /> : <Sun size={16} color={t.inkMuted} />}
        </Card>
        <Card t={t} onClick={changeBranch} style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontSize: 14, fontWeight: 600, color: t.ink }}>Change branch ({state.branch})</span>
          <ChevronRight size={16} color={t.inkMuted} />
        </Card>
      </div>
    </div>
  );
}

/* ============================================================
   BOTTOM NAV
   ============================================================ */
function BottomNav({ screen, go, t }) {
  const navItems = [
    { key: "home", icon: Home, label: "Home" },
    { key: "daily", icon: Zap, label: "Daily" },
    { key: "subjects", icon: BookOpen, label: "Subjects" },
    { key: "pyq", icon: FileText, label: "PYQ" },
    { key: "resources", icon: Compass, label: "Resources" },
    { key: "more", icon: Menu, label: "More" },
  ];
  const activeSet = { home: "home", daily: "daily", subjects: "subjects", subjectDetail: "subjects",
    pyq: "pyq", more: "more", aptitude: "more", progress: "more", resources: "resources" };
  const active = activeSet[screen] || "home";
  return (
    <div style={{
      position: "fixed", bottom: 0, left: 0, right: 0, backgroundColor: t.surface,
      borderTop: `1px solid ${t.border}`, display: "flex", justifyContent: "space-around",
      padding: "10px 6px calc(10px + env(safe-area-inset-bottom))", zIndex: 20,
    }}>
      {navItems.map(({ key, icon: Icon, label }) => {
        const isActive = active === key;
        return (
          <button key={key} onClick={() => go(key)} style={{
            background: "none", border: "none", display: "flex", flexDirection: "column",
            alignItems: "center", gap: 3, cursor: "pointer", color: isActive ? t.accent : t.inkMuted,
            fontFamily: FONT_BODY, padding: "4px 10px",
          }}>
            <Icon size={20} />
            <span style={{ fontSize: 10, fontWeight: isActive ? 700 : 500 }}>{label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ============================================================
   ROOT APP
   ============================================================ */
export default function GatePrepApp() {
  useFonts();
  const [state, setState] = useState(DEFAULT_STATE);
  const [loaded, setLoaded] = useState(false);
  const [screen, setScreen] = useState("branchSelect");
  const [activeSubject, setActiveSubject] = useState(null);

  useEffect(() => {
    (async () => {
      const s = await loadState();
      setState(s);
      setScreen(s.branch ? "home" : "branchSelect");
      setLoaded(true);
    })();
  }, []);

  const persist = useCallback((next) => {
    setState(next);
    saveState(next);
  }, []);

  const selectBranch = (branchId) => {
    const next = { ...state, branch: branchId };
    persist(next);
    setScreen("home");
  };

  const toggleTheme = () => {
    persist({ ...state, theme: state.theme === "light" ? "dark" : "light" });
  };

  const changeBranch = () => setScreen("branchSelect");

  const recordAnswer = (question, correct) => {
    const today = todayStr();
    const attempts = { ...state.attempts };
    const prev = attempts[question.id];
    attempts[question.id] = {
      correct,
      lastAnswered: today,
      nextReview: correct ? null : addDays(today, 3),
      timesWrong: correct ? (prev?.timesWrong || 0) : (prev?.timesWrong || 0) + 1,
    };

    let { count, lastDate } = state.streak;
    if (lastDate !== today) {
      if (lastDate && daysDiff(lastDate, today) === 1) count += 1;
      else count = 1;
      lastDate = today;
    }

    const stats = { solved: state.stats.solved + 1, correct: state.stats.correct + (correct ? 1 : 0) };
    persist({ ...state, attempts, streak: { count, lastDate }, stats });
  };

  const t = THEMES[state.theme];

  if (!loaded) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", backgroundColor: THEMES.light.bg }}>
        <GraduationCap size={30} color={THEMES.light.accent} />
      </div>
    );
  }

  const go = (key) => {
    setActiveSubject(null);
    setScreen(key);
  };

  return (
    <div style={{
      minHeight: "100vh", backgroundColor: t.bg, fontFamily: FONT_BODY, color: t.ink,
      maxWidth: 480, margin: "0 auto", position: "relative",
    }}>
      {screen === "branchSelect" && <BranchSelectScreen onSelect={selectBranch} t={t} />}
      {screen === "home" && <HomeScreen state={state} t={t} go={go} />}
      {screen === "daily" && <DailyScreen state={state} t={t} onAnswer={recordAnswer} onBack={() => go("home")} />}
      {screen === "subjects" && !activeSubject && (
        <SubjectsScreen state={state} t={t} onOpenSubject={(s) => { setActiveSubject(s); setScreen("subjectDetail"); }} onBack={() => go("home")} />
      )}
      {screen === "subjectDetail" && activeSubject && (
        <SubjectDetailScreen subject={activeSubject} state={state} t={t} onAnswer={recordAnswer}
          onBack={() => { setActiveSubject(null); setScreen("subjects"); }} />
      )}
      {screen === "pyq" && <PYQScreen state={state} t={t} onAnswer={recordAnswer} onBack={() => go("home")} />}
      {screen === "aptitude" && <AptitudeScreen t={t} onAnswer={recordAnswer} onBack={() => go("home")} />}
      {screen === "progress" && <ProgressScreen state={state} t={t} onBack={() => go("home")} />}
      {screen === "resources" && <ResourcesScreen state={state} t={t} go={go} onBack={() => go("home")} />}
      {screen === "more" && (
        <MoreScreen state={state} t={t} go={go} toggleTheme={toggleTheme} changeBranch={changeBranch} onBack={() => go("home")} />
      )}

      {screen !== "branchSelect" && <div style={{ height: 70 }} />}
      {screen !== "branchSelect" && <BottomNav screen={screen} go={go} t={t} />}
    </div>
  );
}
